# IDEAS ---------------------------------
- InputHandler 
	-> into a control node, so mouse input can be limited to a region

- NextIndicator
	-> TextureRect?, because it's lacking a lot of basic texture settings.

- No stopping error when trying to show portraits please, just print an error please!

- Portrait speaker accent feature!
- Portrait update mode assumes to update ALL settings (e.g. Mirror, position, etc.) even if not set.
- Portrait missing check if position exists results in error
- Portrait position 0 isn't saved and then position 1 is assumed
